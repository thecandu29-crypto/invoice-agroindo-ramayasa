PT. AGROINDO RAMA YASA — ANDROID APK PROJECT V2

Isi:
- index.html: versi HTML untuk dibuka di Chrome.
- logo.png: logo asli yang diunggah.
- app/: aplikasi Android WebView yang memuat HTML lokal.
- .github/workflows/build-apk.yml: build APK otomatis melalui GitHub Actions.

Build APK otomatis dari HP:
1. Buat repository baru di GitHub (nama: agroindo-invoice).
2. Upload seluruh isi folder/ZIP ini ke repository, pastikan folder .github ikut ter-upload.
3. Buka tab Actions di repository.
4. Jalankan workflow "Build APK Android" (Run workflow) atau tunggu build otomatis selesai setelah push ke main.
5. Buka hasil run yang sukses, cari bagian Artifacts, unduh "PT-AGROINDO-RAMA-YASA-APK".
6. Ekstrak artifact ZIP dan instal app-debug.apk di Android.

Catatan:
- Ini source project siap-build, bukan APK binary. APK harus dikompilasi oleh GitHub Actions.
- APK yang dibuat adalah debug APK untuk instalasi langsung pada HP, bukan rilis Play Store.
- Instalasi mungkin meminta izin "Install unknown apps" untuk browser/File Manager.
